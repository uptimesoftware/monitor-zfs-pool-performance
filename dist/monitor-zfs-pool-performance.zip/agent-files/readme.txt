Make an entry in the /opt/uptime-agent/bin/.uptmpasswd file with a password and corresponding script. The entry should be in the following format :

PASSWORD /opt/uptime-agent/scripts/ZFS_Pool_Performance_Monitor.sh