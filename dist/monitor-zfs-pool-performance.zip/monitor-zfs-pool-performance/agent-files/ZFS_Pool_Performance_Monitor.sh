#!/bin/bash
/usr/sbin/zpool iostat -v